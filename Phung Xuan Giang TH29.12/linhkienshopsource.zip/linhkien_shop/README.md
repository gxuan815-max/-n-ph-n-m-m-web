# Website bán linh kiện máy tính (PHP + MySQL)

Đồ án môn Lập trình Web. PHP thuần (PDO) + MySQL/MariaDB, không dùng framework.

## Cài đặt với XAMPP
1. Bật **Apache** và **MySQL** trong XAMPP Control Panel.
2. Chép thư mục `website/` vào `C:\xampp\htdocs\linhkien\`.
3. Mở http://localhost/phpmyadmin, ở trang chủ phpMyAdmin (chưa chọn CSDL nào) vào tab **Nhập (Import)**:
   nạp `sql/schema.sql` trước, rồi `sql/data.sql` (13 danh mục, 42 hãng, 138 sản phẩm).
4. Kiểm tra `website/includes/config.php` (mặc định: localhost / root / mật khẩu rỗng).
5. Truy cập:
   - Khách hàng: http://localhost/linhkien/
   - Quản trị: http://localhost/linhkien/admin/ với tài khoản **admin / admin123** (đổi mật khẩu khi triển khai thật)

Yêu cầu: PHP >= 7.4, MySQL 5.7+ hoặc MariaDB 10.x.

## Chạy nhanh bằng dòng lệnh (không cần XAMPP)
    mysql -u root < sql/schema.sql
    mysql -u root < sql/data.sql
    cd website && php -S localhost:8080

## Chức năng
- Khách hàng: xem, tìm, lọc (danh mục, giá theo triệu đồng) có phân trang; chi tiết; giỏ hàng; đặt hàng
  (giao dịch và trừ tồn kho); đăng ký, đăng nhập; lịch sử đơn; đánh giá; liên hệ.
- Admin: tổng quan và thống kê; thêm, sửa, xóa sản phẩm và danh mục; quản lý đơn hàng (đổi trạng thái, xóa),
  khách hàng, đánh giá, liên hệ.

## Hạn chế đã biết
Chưa có token chống CSRF, chưa upload ảnh sản phẩm (dùng emoji), chưa thanh toán online.
